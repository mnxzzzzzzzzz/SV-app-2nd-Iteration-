import { OrbitAIChat } from "../orbit-ai/OrbitAIChat"

export function OrbitScreen() {
  return <OrbitAIChat />
}
